const commentModel = require('../models/comment');

const allComments = async (req, res)=>{ }

module.exports = {
    allComments
};
