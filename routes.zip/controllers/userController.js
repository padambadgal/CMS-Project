const userModel = require('../models/user');



const loginPage = async (req, res) =>{ }
const adminLogin = async (req, res) =>{ }
const logout = async (req, res) =>{ }

const allUser = async (req, res) =>{ }
const addUserPage = async (req, res) =>{ }
const addUser = async (req, res) =>{ }
const updateuserPage = async (req, res) =>{ }
const updateUser = async (req, res) =>{ }
const deleteuser = async (req, res) =>{ }

module.exports = {
    loginPage,
    adminLogin,
    logout,
    allUser,
    addUserPage,
    addUser,
    updateuserPage,
    updateUser,
    deleteuser
}