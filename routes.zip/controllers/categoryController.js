const categoryModel = require('../models/category');

const allCategory = async (req, res) => { }
const addCategoryPage = async (req, res) => { }
const addCategory = async (req, res) => { }
const updateCategoryPage = async (req, res) => { }
const updateCategory = async (req, res) => { }
const deleteCategory = async (req, res) => { }

module.exports = {
    allCategory,
    addCategoryPage,
    addCategory,
    updateCategoryPage,
    updateCategory,
    deleteCategory
}