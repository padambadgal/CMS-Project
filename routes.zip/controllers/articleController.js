const categoryModel = require('../models/category');
const newsModel = require('../models/news');
const userModel = require('../models/user');
const commentModel = require('../models/comment');

const allArticle = async (req, res) =>{ }
const addUserArticle = async (req, res) =>{ }
const addArticle = async (req, res) =>{ }
const updateArticlePage = async (req, res) =>{ }
const updateArticle = async (req, res) =>{ }
const deleteArticle = async (req, res) =>{ }

module.exports = {
    allArticle,
    addUserArticle,
    addArticle,
    updateArticlePage,
    updateArticle,
    deleteArticle
}